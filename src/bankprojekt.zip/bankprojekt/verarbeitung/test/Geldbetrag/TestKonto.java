package bankprojekt.verarbeitung.test.Geldbetrag;

import bankprojekt.verarbeitung.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

public class TestKonto {



}
